/*
 * package com.jpaproj.app;
 * 
 * 
 * import java.util.Date; import java.util.List;
 * 
 * import com.jpaproj.dao.ServiceDao; import com.jpaproj.model.Flight;
 * 
 * 
 * public class AssociationTest {
 * 
 * public static void main(String[] args) {
 * 
 * Flight flight = new Flight(); flight.setFlightid("F106");
 * flight.setAirline("GoAir"); flight.setSource("Del");
 * flight.setDestination("Mum");
 * 
 * 
 * boolean result = new ServiceDao().addFlight(flight);
 * System.out.println(result);
 * 
 * List<Flight> flightlist = new FlightDao().searchAll(); for(Flight
 * flight:flightlist) {
 * System.out.printf("\nFlight:%20s %20s %20s",flight.getFlightid(),flight.
 * getSource(),flight.getDestination()); System.out.printf("\n*************");
 * for(Booking booking:flight.getBookinglist()) {
 * System.out.printf("\n%10s %10s %10s %10s ",booking.getBookingid(),
 * booking.getName(), booking.getEmailid(), booking.getBookingdate()); }
 * System.out.printf("\n-------"); }
 * 
 * System.exit(0);
 * 
 * }
 * 
 * }
 */
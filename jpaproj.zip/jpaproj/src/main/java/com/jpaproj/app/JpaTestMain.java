package com.jpaproj.app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpaproj.dao.ServiceDao;
import com.jpaproj.model.Alien;

public class JpaTestMain {
public static void main( String arg[]) {
	//new ServiceDao().addAlien(new Alien());
	Alien alien = new Alien();
	alien.setAid(1012);
	alien.setAname("abc");
	alien.setAtech("xyz");
	//boolean flag = new ServiceDao().addAlien(alien);
	//System.out.println(flag);
	/*Alien a = new Alien();
    a.setAid(9);
    a.setAname("Maria");
    a.setAtech("Hardware");
    */
  	/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
  	EntityManager em = emf.createEntityManager();
  	
  	em.getTransaction().begin();
  	em.persist(alien);
  	em.getTransaction().commit();
  	System.out.println(alien);*/
	System.exit(0);
}
}

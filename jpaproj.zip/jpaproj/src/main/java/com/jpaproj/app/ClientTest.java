package com.jpaproj.app;

import com.jpaproj.dao.ServiceDao;
import com.jpaproj.entity.AlienEntity;
import com.jpaproj.model.Alien;
import com.jpaproj.service.AlienServiceImpl;

public class ClientTest {

	public static void main(String[] args) {
		Alien entity = new Alien();
		entity.setAid(700);
		entity.setAname("Sai");
		entity.setAtech("Ram");
		entity.setSal(5555);
		new AlienServiceImpl().addAlien(entity);
		
		Alien a = new AlienServiceImpl().getAlienById(700);
		System.out.println(a);

	}

}

package com.jpaproj.service;

import com.jpaproj.dao.AlienDao;
import com.jpaproj.dao.AlienDaoImpl;
import com.jpaproj.model.Alien;


public class AlienServiceImpl implements AlienService{
    private AlienDao alienDao;
    
	public AlienServiceImpl() {
		this.alienDao = new AlienDaoImpl();
	}

	public Alien getAlienById(Integer id) {
		return alienDao.getAlienById(id);
	}

	public void addAlien(Alien alien) {
		alienDao.addAlien(alien);
		
	}

}

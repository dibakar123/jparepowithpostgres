package com.jpaproj.service;

import com.jpaproj.model.Flight;

public interface FlightService {
	public abstract Flight getFlightById(Integer id);

	public abstract void addFlight(Flight flight);
}
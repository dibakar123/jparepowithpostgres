package com.jpaproj.service;

import com.jpaproj.dao.FlightDao;
import com.jpaproj.dao.FlightDaoImpl;
import com.jpaproj.model.Flight;

public class FlightServiceImpl implements FlightService{
    private FlightDao flightDao;
    
	public FlightServiceImpl() {
		this.flightDao = new FlightDaoImpl();
	}

	public Flight getFlightById(Integer id) {
		return flightDao.getFlightById(id);
	}

	public void addFlight(Flight flight) {
		flightDao.addFlight(flight);
		
	}

}

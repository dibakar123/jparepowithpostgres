package com.jpaproj.service;

import com.jpaproj.model.Alien;


public interface AlienService {
	public abstract Alien getAlienById(Integer id);
	public abstract void addAlien(Alien alien);
}
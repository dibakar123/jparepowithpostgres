package com.jpaproj.entity;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="alien")
public class AlienEntity implements Serializable
{
	@Id
	private int aid;
	private String aname;
	private String atech;
	private int sal;
	
	@Override
	public String toString() {
		return "AlienEntity [aid=" + aid + ", aname=" + aname + ", atech=" + atech + ", sal=" + sal + "]";
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAtech() {
		return atech;
	}
	public void setAtech(String atech) {
		this.atech = atech;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	
	
	
}

package com.jpaproj.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpaproj.entity.AlienEntity;
import com.jpaproj.entity.FlightEntity;
import com.jpaproj.model.Alien;
import com.jpaproj.model.Flight;



public class AlienDaoImpl implements AlienDao{

	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;

	public AlienDaoImpl() {
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		//entityManagerFactory = Persistence.createEntityManagerFactory("pu");
		entityManager = entityManagerFactory.createEntityManager();
	}
	
	public Alien getAlienById(Integer id) {
		AlienEntity entity = entityManager.find(AlienEntity.class, id); // search record in table based on Pk Id
		Alien alien = new Alien();
		alien.setAid(entity.getAid());
		alien.setAname(entity.getAname());
		alien.setAtech(entity.getAtech());
		return alien;
	}

	public void addAlien(Alien alien) {
		 	
	  	AlienEntity entity = new AlienEntity();
	  	entity.setAid(alien.getAid());
	  	entity.setAname(alien.getAname());
	  	entity.setAtech(alien.getAtech());
	  	entity.setSal(alien.getSal());
	  	beginTransaction();
	  	  entityManager.persist(entity); // insert into table a new row
		commitTransaction();
		
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

}

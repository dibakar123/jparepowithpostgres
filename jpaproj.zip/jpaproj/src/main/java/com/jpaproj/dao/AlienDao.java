package com.jpaproj.dao;

import com.jpaproj.model.Alien;


public interface AlienDao {
	public abstract Alien getAlienById(Integer id);

	public abstract void addAlien(Alien alien);

	public void beginTransaction() ;

	public void commitTransaction() ;
}

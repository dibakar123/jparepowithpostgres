package com.jpaproj.dao;

import com.jpaproj.model.Flight;

public interface FlightDao {
	public abstract Flight getFlightById(Integer id);

	public abstract void addFlight(Flight flight);
}

package com.jpaproj.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpaproj.entity.FlightEntity;
import com.jpaproj.model.Flight;



public class FlightDaoImpl implements FlightDao{

	public Flight getFlightById(Integer id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	  	EntityManager em = emf.createEntityManager();
		FlightEntity entity = em.find(FlightEntity.class, id);
		Flight flight = new Flight();
		flight.setName(entity.getName());
		flight.setDestination(entity.getDestination());
		flight.setId(entity.getId());
		flight.setSource(entity.getSource());
		return flight;
	}

	public void addFlight(Flight flight) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	  	EntityManager em = emf.createEntityManager();
	  	
	  	/*FlightEntity entity = new FlightEntity();
	  	entity.setAirline(flight.getAirline());
	  	entity.setDestination(flight.getDestination());
	  	entity.setFlightid(flight.getFlightid());
	  	entity.setSource(flight.getSource());*/
	  	FlightEntity flight1 = new FlightEntity();
		flight1.setId(new Integer(111));
		flight1.setName("GoAir");
		flight1.setSource("Del");
		flight1.setDestination("Mum");
		
	  	em.getTransaction().begin();
	  	try{
	  		em.persist(flight1);
	  	}
	  	catch(Exception e) {
	  		System.out.println("Error:"+e);
	  	}
	  	em.getTransaction().commit();
		
	}

}

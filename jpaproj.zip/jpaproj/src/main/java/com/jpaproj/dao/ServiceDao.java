package com.jpaproj.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jpaproj.entity.AlienEntity;
import com.jpaproj.model.Alien;
import com.jpaproj.model.Flight;



public class ServiceDao {
	public boolean addAlien(Alien entity){
		 boolean result=false;
		 try{
			 AlienEntity en = new AlienEntity();
			 en.setAid(entity.getAid());
			 en.setAname(entity.getAname());
			 en.setAtech(entity.getAtech());
			 EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		     
			 EntityManager em = emf.createEntityManager();
		     
		     em.getTransaction().begin();
		     em.persist(en);
		     em.getTransaction().commit();
		     em.close();
		     emf.close();
		    	
		    /*	em.getTransaction().commit();
		    	em.close();
			    emf.close();
		    	System.out.println(alien);
			// Alien a = new Alien();
			  //  a.setAid(199);
			  //  a.setAname("Maria");
			   // a.setAtech("Hardware");
			    
			  	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			  	EntityManager em = emf.createEntityManager();
			  	
			  	em.getTransaction().begin();
			  	em.persist(a);
			  	em.getTransaction().commit();
			  	System.out.println(a);*/
		    	result=true;
		 }
		catch(Exception e){	System.out.println("Error:"+e);	}
		return result;
	 }
	
	public boolean addFlight(Flight f){
		 boolean result=false;
		 try{
			 EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			 EntityManager em = emf.createEntityManager();
			  	
			 em.getTransaction().begin();
			 em.persist(f);
			 em.getTransaction().commit();
			// System.out.println(f.getAirline());
		     result=true;
			 
		 }
		catch(Exception e){	System.out.println("Error:"+e);	}
		return result;
	 }
	
	
}
